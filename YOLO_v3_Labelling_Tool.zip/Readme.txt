https://github.com/developer0hye/Yolo_Label

Install and Run
- Download this project

[For Windows]
- Download YOLOLabel_v1.2.1.zip
- Unzip
- Run YoloLabel.exe

[For Ubuntu 22.04]
- Download YOLOLabel_v1.2.1.tar
- Unzip and download libraries

tar -xvf YoloLabel_v1.2.1.tar
sudo apt update
sudo apt-get install -y libgl1-mesa-dev
sudo apt-get install libxcb-*
sudo apt-get install libxkb*

- Run YoloLabel.sh
./YoloLabel.sh

[For macOS]
- Clone or download the source code of this repository
- Open terminal and type command in the downloaded directory.

yourMacOS:Yolo_Label you$ qmake
yourMacOS:Yolo_Label you$ make

- Run YoloLabel.app/Contents/MacOS/YoloLabel in terminal
- or double click YoloLabel.app to run
yourMacOS:Yolo_Label you$ ./YoloLabel.app/MacOS/YoloLabel
